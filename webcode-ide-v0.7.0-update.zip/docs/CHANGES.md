# Dokumentasi Perubahan dari Acode 1.13.5

Fork pribadi **Irham.s.a WebCode IDE**. Daftar versi, dari yang terbaru:

| Versi | Nama | Ringkasan | Dokumen |
|---|---|---|---|
| 0.7.0 | Kembali ke atas + play melayang | header kembali ke atas, play melayang di kanan, drawer dari kiri dengan folder di atas, Beranda permanen, default editor 11px + bungkus baris | `versions/v0.7.0.md` |
| 0.6.0 | Rel kanan + pembersihan native | top bar jadi rel vertikal kanan, drawer menempel, tab di atas, plugin native tak terpakai dibuang | `versions/v0.6.0.md` |
| 0.5.1 | Perbaikan Beranda + tata letak | Beranda muncul lagi, warna aktif diperbaiki, rel ikon drawer di bawah, tab di bawah, header kapsul | `versions/v0.5.1.md` |
| 0.5.0 | Rombak | desain baru, terminal/login/plugin dibuang dari antarmuka, tema bawaan baru | `versions/v0.5.0.md` |
| 0.4.2 | Perbaikan urutan hook | hook Java ditunggu Cordova; patch fullscreen tidak lagi tertimpa | `versions/v0.4.2.md` |
| 0.4.1 | Perbaikan build Windows | hook Java tidak lagi gagal `ENOENT G:\G:\...wasm` | `versions/v0.4.1.md` |
| 0.4.0 | Preview | input file dan download di preview berjalan di dalam app | `versions/v0.4.0.md` |
| 0.3.0 | Pengembang | halaman About berisi data pengembang, logo di dalam app | `versions/v0.3.0.md` |
| 0.2.0 | Tema | 19 tema editor, 11 tema aplikasi, 6 tema terminal baru | `versions/v0.2.0.md` |
| 0.1.0 | Fondasi | rebrand, ikon, package name, fitur online dibuang | `versions/v0.1.0.md` |

Aturan penomoran: versi selalu naik. Setiap rilis wajib punya satu file `docs/versions/vX.Y.Z.md`, dan `config.xml` (`version`, `android-versionCode`) serta `package.json` (`version`) dinaikkan bersamaan.

## Rencana berikutnya (usulan, belum dikerjakan)
- v0.5.0: bersihkan sisa fitur online (FTP/SFTP, halaman about/changelog, dialog yang menyebut Acode), pilih tema default.
- v0.6.0: sesuaikan terminal dan LSP (dibuang atau dibuat benar-benar offline).
- v0.7.0: logo/ikon alternatif dan splash sendiri.

## Lisensi
Dasar kode: Acode © Foxdebug (Ajit Kumar), lisensi MIT. File `license.txt` **harus tetap ada**. Lihat `NOTICE-WEBCODE.md`.
